/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        sage: {
          50: '#f6f7f6',
          100: '#e3e7e3',
          200: '#c7d0c7',
          300: '#a3b1a3',
          400: '#7d8f7d',
          500: '#637463',
          600: '#4d5b4d',
          700: '#3f4a3f',
          800: '#343c34',
          900: '#2c332c',
          950: '#171917',
        },
        secondary: {
          50: '#f0fbe9',
          100: '#dcf6cc',
          200: '#b8ec99',
          300: '#8bdb5d',
          400: '#49B522', // Main secondary color
          500: '#3d9b1c',
          600: '#317c16',
          700: '#275d11',
          800: '#1f4a0e',
          900: '#193c0b',
          950: '#0c1f06',
        },
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { Toaster } from 'sonner';
import { Layout } from './components/layout';
import { AboutPage } from './pages/about';
import { AdventuresPage } from './pages/adventures';
import { BlogPage } from './pages/blog';
import { BookingPage } from './pages/booking';
import { ContactPage } from './pages/contact';
import { FaqPage } from './pages/faq';
import { HomePage } from './pages/home';
import { PrivacyPage } from './pages/privacy';
import { TermsPage } from './pages/terms';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/adventures" element={<AdventuresPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/booking" element={<BookingPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/faq" element={<FaqPage />} />
          <Route path="/terms" element={<TermsPage />} />
          <Route path="/privacy" element={<PrivacyPage />} />
        </Routes>
      </Layout>
      <Toaster position="top-center" />
    </Router>
  );
}

export default App;
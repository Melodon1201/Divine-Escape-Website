import { Mountain, Sprout, Tent, Users } from 'lucide-react';
import { DifferenceCard } from './difference-card';
import { SectionHeader } from '../ui/section-header';
import { differences } from '@/lib/constants/differences';

const icons = {
  Users,
  Mountain,
  Tent,
  Sprout,
} as const;

export function DifferenceSection() {
  return (
    <div className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <SectionHeader
          title="The Divine Escape Difference"
          description="Experience what sets us apart: intimate groups, unique locations, and a focus on holistic growth."
        />
        <dl className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-16 text-base leading-7 sm:grid-cols-2 lg:mx-0 lg:max-w-none lg:gap-x-16">
          {differences.map((difference) => (
            <DifferenceCard
              key={difference.title}
              {...difference}
              Icon={icons[difference.icon as keyof typeof icons]}
            />
          ))}
        </dl>
      </div>
    </div>
  );
}
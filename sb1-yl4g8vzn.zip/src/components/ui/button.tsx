import { cn } from '@/lib/utils';
import { type ButtonHTMLAttributes, forwardRef } from 'react';
import { Link } from 'react-router-dom';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
  size?: 'sm' | 'md' | 'lg';
  as?: typeof Link | 'a';
  to?: string;
  href?: string;
  target?: string;
  rel?: string;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', as: Component = 'button', to, href, ...props }, ref) => {
    const styles = cn(
      'inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-secondary-400 disabled:pointer-events-none disabled:opacity-50',
      {
        'bg-sage-600 text-white hover:bg-sage-700': variant === 'primary',
        'bg-secondary-400 text-white hover:bg-secondary-500': variant === 'secondary',
        'border border-secondary-200 bg-white text-secondary-400 hover:bg-secondary-50': variant === 'outline',
        'h-9 px-4 py-2 text-sm': size === 'sm',
        'h-10 px-6 py-2': size === 'md',
        'h-11 px-8 py-3 text-lg': size === 'lg',
      },
      className
    );

    if (Component === Link && to) {
      return (
        <Component to={to} className={styles} {...(props as any)}>
          {props.children}
        </Component>
      );
    }

    if (Component === 'a' && href) {
      return (
        <a href={href} className={styles} {...props}>
          {props.children}
        </a>
      );
    }

    return <button ref={ref} className={styles} {...props} />;
  }
);

Button.displayName = 'Button';

export { Button };
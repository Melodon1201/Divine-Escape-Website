import { motion } from 'framer-motion';
import { type PropsWithChildren } from 'react';
import { useInView } from 'react-intersection-observer';

interface SlideInProps extends PropsWithChildren {
  direction?: 'left' | 'right';
  delay?: number;
}

export function SlideIn({ children, direction = 'left', delay = 0 }: SlideInProps) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const initialX = direction === 'left' ? -100 : 100;

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: initialX }}
      animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: initialX }}
      transition={{ duration: 0.6, delay }}
    >
      {children}
    </motion.div>
  );
}
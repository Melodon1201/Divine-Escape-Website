import { type HTMLAttributes } from 'react';
import { cn } from '@/lib/utils';

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  hover?: boolean;
}

export function Card({ className, hover, ...props }: CardProps) {
  return (
    <div
      className={cn(
        'rounded-lg bg-white p-6 shadow-md ring-1 ring-gray-900/5',
        {
          'transition-transform duration-200 hover:scale-105': hover,
        },
        className
      )}
      {...props}
    />
  );
}
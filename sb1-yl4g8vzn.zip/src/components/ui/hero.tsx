import { type ReactNode } from 'react';
import { motion } from 'framer-motion';

interface HeroProps {
  image: string;
  children: ReactNode;
}

export function Hero({ image, children }: HeroProps) {
  return (
    <div className="relative">
      <div className="absolute inset-0">
        <img
          className="h-full w-full object-cover"
          src={image}
          alt="Hero background"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900/80 to-gray-900/60 backdrop-blur-[2px]" />
      </div>
      <div className="relative mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          {children}
        </motion.div>
      </div>
    </div>
  );
}
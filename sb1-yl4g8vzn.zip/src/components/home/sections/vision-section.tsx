import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { SectionHeader } from '@/components/ui/section-header';

export function VisionSection() {
  return (
    <div className="bg-secondary-50 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <SectionHeader
          title="Our Vision"
          description="At Divine Escape, we envision a world where individuals can find peace, purpose,
            and connection through mindful adventures. We believe in the power of nature to
            heal, transform, and inspire. Our experiences are designed to help you disconnect
            from the daily grind and reconnect with what truly matters."
        />
        <div className="mt-10 flex justify-center">
          <Button as={Link} to="/about" variant="secondary" size="lg">
            Learn More About Us
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
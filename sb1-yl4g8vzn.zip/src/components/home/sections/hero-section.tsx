import { ArrowRight, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Hero } from '@/components/ui/hero';
import { heroImages } from '@/lib/constants/images';

export function HeroSection() {
  return (
    <Hero image={heroImages.home}>
      <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl lg:text-7xl">
        <span className="block">Escape the Daily Grind:</span>
        <span className="block text-secondary-400">
          Your Adventurous Journey to Wholeness and Liberation...
        </span>
      </h1>
      <p className="mt-6 max-w-xl text-xl text-gray-200">
        Experience transformative adventures that blend nature, mindfulness, and personal growth.
        Join us for unique escapes designed to rejuvenate your spirit.
      </p>
      <div className="mt-10 flex items-center gap-x-6">
        <Button
          as={Link}
          to="/booking"
          size="lg"
          variant="secondary"
        >
          Book Your Adventure
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
        <Button
          as="a"
          href="https://forms.zohopublic.com/ndumimagd119gm1/form/DivineEscapeRebootRetreat/formperma/EKDUh-v01posU1Y43Gh9suaFGxJQTO9WOwFPkEVprts"
          target="_blank"
          rel="noopener noreferrer"
          variant="outline"
          size="lg"
          className="bg-transparent text-white hover:bg-white/10"
        >
          Book Reboot the Soul Retreat
          <ExternalLink className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </Hero>
  );
}
import { SectionHeader } from '@/components/ui/section-header';
import { FeatureGrid } from '../feature-grid';

export function WelcomeSection() {
  return (
    <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
      <SectionHeader
        title="Welcome to Divine Escape"
        description="We are a holistic adventure company dedicated to providing transformative experiences
          that combine the thrill of outdoor adventures with mindful practices. Our mission is
          to help you discover inner peace and personal growth through carefully curated
          experiences in nature."
      />
      <FeatureGrid />
    </div>
  );
}
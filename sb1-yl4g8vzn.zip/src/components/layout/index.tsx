import { type PropsWithChildren } from 'react';
import { Footer } from './footer/footer';
import { Header } from './header';
import { BackToTop } from '../ui/back-to-top';

export function Layout({ children }: PropsWithChildren) {
  return (
    <div className="min-h-screen">
      <Header />
      <main className="pt-16">{children}</main>
      <Footer />
      <BackToTop />
    </div>
  );
}
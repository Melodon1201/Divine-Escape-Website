import { Copyright } from './copyright';
import { FooterNav } from './footer-nav';
import { LegalLinks } from './legal-links';
import { SocialLinks } from './social-links';

export function Footer() {
  return (
    <footer className="bg-white">
      <div className="mx-auto max-w-7xl overflow-hidden px-6 py-20 sm:py-24 lg:px-8">
        <FooterNav />
        <SocialLinks />
        <LegalLinks />
        <Copyright />
      </div>
    </footer>
  );
}
import { Link } from 'react-router-dom';

export function LegalLinks() {
  return (
    <div className="mt-10 flex justify-center space-x-8 text-sm text-gray-500">
      <Link
        to="/terms"
        className="hover:text-sage-600"
      >
        Terms & Conditions
      </Link>
      <Link
        to="/privacy"
        className="hover:text-sage-600"
      >
        Privacy Policy
      </Link>
    </div>
  );
}
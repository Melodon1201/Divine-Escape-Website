import { Link } from 'react-router-dom';
import { navigation } from '@/lib/constants/navigation';

export function FooterNav() {
  return (
    <nav className="-mb-6 columns-2 sm:flex sm:justify-center sm:space-x-12" aria-label="Footer">
      {navigation.main.map((item) => (
        <div key={item.name} className="pb-6">
          <Link to={item.href} className="text-sm leading-6 text-gray-600 hover:text-sage-600">
            {item.name}
          </Link>
        </div>
      ))}
    </nav>
  );
}
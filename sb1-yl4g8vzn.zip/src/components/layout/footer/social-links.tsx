import { Facebook, Instagram } from 'lucide-react';
import { navigation } from '@/lib/constants/navigation';

const TikTok = ({ className }: { className?: string }) => (
  <svg
    stroke="currentColor"
    fill="currentColor"
    strokeWidth="0"
    viewBox="0 0 448 512"
    className={className}
    height="1em"
    width="1em"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M448,209.91a210.06,210.06,0,0,1-122.77-39.25V349.38A162.55,162.55,0,1,1,185,188.31V278.2a74.62,74.62,0,1,0,52.23,71.18V0l88,0a121.18,121.18,0,0,0,1.86,22.17h0A122.18,122.18,0,0,0,381,102.39a121.43,121.43,0,0,0,67,20.14Z" />
  </svg>
);

const icons = {
  Facebook,
  Instagram,
  TikTok,
} as const;

export function SocialLinks() {
  return (
    <div className="mt-10 flex justify-center space-x-10">
      {navigation.social.map((item) => {
        const Icon = icons[item.icon as keyof typeof icons];
        return (
          <a key={item.name} href={item.href} className="text-gray-400 hover:text-sage-600">
            <span className="sr-only">{item.name}</span>
            <Icon className="h-6 w-6" aria-hidden="true" />
          </a>
        );
      })}
    </div>
  );
}
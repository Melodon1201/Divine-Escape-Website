import { DesktopNav } from './nav/desktop-nav';
import { MobileNav } from './nav/mobile-nav';
import { Logo } from '../brand/logo';

export function Header() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 bg-white/80 backdrop-blur-sm">
      <nav className="mx-auto flex max-w-7xl items-center justify-between p-6 lg:px-8" aria-label="Global">
        <div className="flex lg:flex-1">
          <Logo />
        </div>
        <MobileNav />
        <DesktopNav />
      </nav>
    </header>
  );
}
import { AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { MobileMenuButton } from './mobile-nav/mobile-menu-button';
import { MobileMenuOverlay } from './mobile-nav/mobile-menu-overlay';
import { MobileMenuPanel } from './mobile-nav/mobile-menu-panel';

export function MobileNav() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <div className="flex lg:hidden">
        <MobileMenuButton onClick={() => setIsOpen(true)} />
      </div>

      <AnimatePresence>
        {isOpen && (
          <>
            <MobileMenuOverlay onClick={() => setIsOpen(false)} />
            <MobileMenuPanel onClose={() => setIsOpen(false)} />
          </>
        )}
      </AnimatePresence>
    </>
  );
}
import { X } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { navigation } from '@/lib/constants/navigation';

interface MobileMenuPanelProps {
  onClose: () => void;
}

export function MobileMenuPanel({ onClose }: MobileMenuPanelProps) {
  return (
    <motion.div
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed inset-y- right-0 z-50 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10"
    >
      <div className="flex items-center justify-between">
        <Link
          to="/"
          className="-m-1.5 p-1.5 text-2xl font-normal text-sage-700"
          onClick={onClose}
        >
          Divine Escape
        </Link>
        <Link
          to="/"
          className="-m-1.5 p-1.5 text-2xl font-normal text-sage-700"
          onClick={onClose}
        >
          About
        </Link>
        <button
          type="button"
          className="group -m-2.5 rounded-md p-2.5 text-gray-700"
          onClick={onClose}
        >
          <span className="sr-only">Close menu</span>
          <X className="h-6 w-6 transition-colors group-hover:text-sage-600" aria-hidden="true" />
        </button>
      </div>
      <div className="mt-6 flow-root">
        <div className="-my-6 divide-y divide-gray-500/10">
          <div className="space-y-2 py-6">
            {navigation.main.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className="group -mx-3 block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-sage-50"
                onClick={onClose}
              >
                <span className="transition-colors group-hover:text-sage-600">
                  {item.name}
                </span>
              </Link>
            ))}
          </div>
          <div className="py-6">
            <Button
              as={Link}
              to="/booking"
              className="w-full"
              onClick={onClose}
            >
              Book Your Escape
            </Button>
            <Button
              as="a"
              href="https://forms.zohopublic.com/ndumimagd119gm1/form/DivineEscapeRebootRetreat/formperma/EKDUh-v01posU1Y43Gh9suaFGxJQTO9WOwFPkEVprts"
              target="https://forms.zohopublic.com/ndumimagd119gm1/form/DivineEscapeRebootRetreat/formperma/EKDUh-v01posU1Y43Gh9suaFGxJQTO9WOwFPkEVprts"
              rel="noopener noreferrer"
              variant="outline"
              className="mt-4 w-full"
              onClick={onClose}
            >
              Book Reboot the Soul Retreat
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
import { motion } from 'framer-motion';

interface MobileMenuOverlayProps {
  onClick: () => void;
}

export function MobileMenuOverlay({ onClick }: MobileMenuOverlayProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.2 }}
      className="fixed inset-0 z-50 bg-gray-900/50 backdrop-blur-sm lg:hidden"
      onClick={onClick}
    />
  );
}
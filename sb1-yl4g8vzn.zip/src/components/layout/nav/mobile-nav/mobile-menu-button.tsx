import { Menu } from 'lucide-react';

interface MobileMenuButtonProps {
  onClick: () => void;
}

export function MobileMenuButton({ onClick }: MobileMenuButtonProps) {
  return (
    <button
      type="button"
      className="group -m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700"
      onClick={onClick}
    >
      <span className="sr-only">Open main menu</span>
      <Menu className="h-6 w-6 transition-colors group-hover:text-sage-600" aria-hidden="true" />
    </button>
  );
}
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { navigation } from '@/lib/constants/navigation';

export function DesktopNav() {
  return (
    <>
      <div className="hidden lg:flex lg:gap-x-12">
        {navigation.main.map((item) => (
          <Link
            key={item.name}
            to={item.href}
            className="text-sm font-semibold leading-6 text-gray-900 hover:text-sage-600"
          >
            {item.name}
          </Link>
        ))}
      </div>
      <div className="hidden lg:flex lg:flex-1 lg:justify-end">
        <Button as={Link} to="/booking">
          Book Your Escape
        </Button>
      </div>
    </>
  );
}
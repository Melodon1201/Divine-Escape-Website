import { Link } from 'react-router-dom';
import { Button } from '../ui/button';

export function CtaSection() {
  return (
    <div className="bg-sage-50">
      <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Ready to Begin Your Journey?
          </h2>
          <p className="mx-auto mt-6 max-w-xl text-lg leading-8 text-gray-600">
            Join us for a transformative experience that will reconnect you with nature and yourself.
          </p>
          <div className="mt-10 flex items-center justify-center gap-x-6">
            <Button as={Link} to="/booking" size="lg">
              Book Your Escape
            </Button>
            <Button as={Link} to="/adventures" variant="secondary" size="lg">
              View Adventures
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
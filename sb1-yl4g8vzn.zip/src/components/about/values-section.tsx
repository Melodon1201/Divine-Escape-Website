import { values } from '@/lib/constants/values';

export function ValuesSection() {
  return (
    <div className="lg:flex lg:flex-auto lg:justify-center">
      <dl className="w-64 space-y-8 xl:w-80">
        {values.map((value) => (
          <div key={value.name} className="flex flex-col-reverse gap-y-4">
            <dt className="text-base leading-7 text-gray-600">{value.description}</dt>
            <dd className="text-2xl font-semibold tracking-tight text-gray-900">
              {value.name}
            </dd>
          </div>
        ))}
      </dl>
    </div>
  );
}
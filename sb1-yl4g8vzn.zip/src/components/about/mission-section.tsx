import { SectionHeader } from '../ui/section-header';

export function MissionSection() {
  return (
    <div className="lg:w-full lg:max-w-2xl lg:flex-auto">
      <SectionHeader
        title="About Us"
        className="lg:text-left"
      />
      <p className="text-xl leading-8 text-gray-600">
        Divine Escape was created to offer intentional spaces where individuals can reconnect
        with God's creation and rediscover their inner peace.
      </p>
      <div className="mt-10 max-w-xl text-base leading-7 text-gray-700">
        <p>
        Our mission is to guide driven individuals toward mindfulness, growth, and a deeper connection with God's divine nature and our inner selves. We envision leading in holistic adventurous experiences, ensuring every participant leaves inspired and empowered.
        </p>
      </div>
    </div>
  );
}
import { ExternalLink } from 'lucide-react';
import { Button } from '../ui/button';
import { SectionHeader } from '../ui/section-header';
import { legalContent } from '@/lib/constants/legal';

export function LegalSection() {
  return (
    <div className="bg-white py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <SectionHeader
          title="Legal Information"
          description="Important information about our terms of service and privacy policy."
          className="mb-16"
        />
        <div className="grid gap-16 lg:grid-cols-2">
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-gray-900">{legalContent.terms.title}</h3>
            <p className="text-base text-gray-600">{legalContent.terms.content}</p>
            <Button
              as="a"
              href="/terms"
              target="_blank"
              rel="noopener noreferrer"
              variant="outline"
            >
              Read our Terms & Conditions
              <ExternalLink className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-gray-900">{legalContent.privacy.title}</h3>
            <p className="text-base text-gray-600">{legalContent.privacy.content}</p>
            <Button
              as="a"
              href="/privacy"
              target="_blank"
              rel="noopener noreferrer"
              variant="outline"
            >
              View our Privacy Policy
              <ExternalLink className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
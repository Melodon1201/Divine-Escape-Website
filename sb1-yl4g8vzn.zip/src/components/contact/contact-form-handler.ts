import { type ContactFormData } from '@/lib/schemas/contact';
import { createMailtoLink } from '@/lib/utils/email';

export function handleContactFormSubmission(data: ContactFormData) {
  const subject = `New Contact Form Submission - ${data.firstName} ${data.lastName}`;
  const body = `
Contact Details:

Name: ${data.firstName} ${data.lastName}
Email: ${data.email}
Phone: ${data.phone}

Message:
${data.message}
  `;

  const mailtoLink = createMailtoLink({
    to: 'info@holisticdivineescape.com',
    subject,
    body,
  });

  window.location.href = mailtoLink;
}
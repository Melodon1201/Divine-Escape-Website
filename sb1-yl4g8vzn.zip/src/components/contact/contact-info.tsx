import { Mail, MapPin, Phone } from 'lucide-react';

export function ContactInfo() {
  return (
    <div className="relative px-6 pb-20 pt-24 sm:pt-32 lg:static lg:px-8 lg:py-48">
      <div className="mx-auto max-w-xl lg:mx-0 lg:max-w-lg">
        <h2 className="text-3xl font-bold tracking-tight text-gray-900">Get in touch</h2>
        <p className="mt-6 text-lg leading-8 text-gray-600">
          Have questions about our adventures? Want to customize your experience? We're here to
          help. Reach out to us and we'll get back to you shortly.
        </p>
        <dl className="mt-10 space-y-4 text-base leading-7 text-gray-600">
          
          <div className="flex gap-x-4">
            <dt className="flex-none">
              <span className="sr-only">Telephone</span>
              <Phone className="h-7 w-6 text-gray-400" aria-hidden="true" />
            </dt>
            <dd>
              <a className="hover:text-gray-900" href="tel:+27662313908">
                066 231 3908
              </a>
            </dd>
          </div>
          <div className="flex gap-x-4">
            <dt className="flex-none">
              <span className="sr-only">Email</span>
              <Mail className="h-7 w-6 text-gray-400" aria-hidden="true" />
            </dt>
            <dd>
              <a className="hover:text-gray-900" href="mailto:
info@holisticdivineescape.com">
                
info@holisticdivineescape.com
              </a>
            </dd>
          </div>
        </dl>
      </div>
    </div>
  );
}
import { type BlogPost } from '@/lib/types';
import { Card } from '../ui/card';
import { Badge } from '../ui/badge';

interface BlogCardProps extends BlogPost {}

export function BlogCard({
  title,
  description,
  date,
  category,
  author,
  image,
}: BlogCardProps) {
  return (
    <Card hover className="flex h-full flex-col">
      <div className="relative">
        <img
          src={image}
          alt={title}
          className="aspect-video w-full rounded-lg object-cover"
        />
      </div>
      <div className="mt-4 flex flex-1 flex-col">
        <div className="flex items-center gap-x-4">
          <time dateTime={date} className="text-sm text-gray-500">
            {new Date(date).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}
          </time>
          <Badge>{category}</Badge>
        </div>
        <h3 className="mt-4 text-xl font-semibold text-gray-900">{title}</h3>
        <p className="mt-2 flex-1 text-gray-600">{description}</p>
        <div className="mt-4 border-t border-gray-100 pt-4">
          <p className="text-sm font-medium text-gray-900">{author}</p>
        </div>
      </div>
    </Card>
  );
}
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { type Testimonial } from '@/lib/types';
import { Card } from '../ui/card';

interface TestimonialCardProps extends Testimonial {}

export function TestimonialCard({ content, author, role, image }: TestimonialCardProps) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.6 }}
    >
      <Card className="flex h-full flex-col items-center space-y-6 transition-transform duration-300 hover:scale-105">
        <div className="relative">
          <img
            className="h-16 w-16 rounded-full object-cover ring-2 ring-secondary-200"
            src={image}
            alt={author}
          />
          <div className="absolute -inset-0.5 animate-pulse rounded-full bg-secondary-100 blur" />
        </div>
        <blockquote className="text-center text-lg font-medium leading-8 text-gray-900">
          "{content}"
        </blockquote>
        <div className="text-center">
          <div className="font-semibold text-gray-900">{author}</div>
          <div className="text-sm text-secondary-600">{role}</div>
        </div>
      </Card>
    </motion.div>
  );
}
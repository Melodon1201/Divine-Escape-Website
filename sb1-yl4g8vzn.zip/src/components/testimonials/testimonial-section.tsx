import { TestimonialCard } from './testimonial-card';
import { SectionHeader } from '../ui/section-header';
import { testimonials } from '@/lib/constants/testimonials';

export function TestimonialSection() {
  return (
    <div className="bg-secondary-50/50 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <SectionHeader
          title="What Our Adventurers Say"
          description="Hear from those who have embarked on the journey to rediscover themselves with Divine Escape."
        />
        <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-8 lg:mx-0 lg:max-w-none lg:grid-cols-3">
          {testimonials.map((testimonial) => (
            <TestimonialCard key={testimonial.author} {...testimonial} />
          ))}
        </div>
      </div>
    </div>
  );
}
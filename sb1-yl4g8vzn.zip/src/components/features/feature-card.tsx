import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

interface FeatureCardProps {
  name: string;
  description: string;
  image: string;
}

export function FeatureCard({ name, description, image }: FeatureCardProps) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <motion.article
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.6 }}
      className="flex flex-col items-start group"
    >
      <div className="relative w-full overflow-hidden rounded-2xl">
        <img
          src={image}
          alt={name}
          className="aspect-[16/9] w-full bg-gray-100 object-cover transition-transform duration-300 group-hover:scale-105 sm:aspect-[2/1] lg:aspect-[3/2]"
        />
      </div>
      <div className="max-w-xl">
        <div className="mt-8 flex items-center gap-x-4 text-xs" />
        <div className="group relative">
          <h3 className="mt-3 text-lg font-semibold leading-6 text-gray-900 transition-colors group-hover:text-secondary-500">
            <span className="absolute inset-0" />
            {name}
          </h3>
          <p className="mt-5 line-clamp-3 text-sm leading-6 text-gray-600">
            {description}
          </p>
        </div>
      </div>
    </motion.article>
  );
}
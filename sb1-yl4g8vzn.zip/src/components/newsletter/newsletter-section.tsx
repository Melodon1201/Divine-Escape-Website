import { SectionHeader } from '../ui/section-header';
import { NewsletterForm } from './newsletter-form';

export function NewsletterSection() {
  return (
    <div className="bg-white py-16 sm:py-24">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="relative isolate overflow-hidden bg-secondary-50 px-6 py-24 shadow-2xl sm:rounded-3xl sm:px-24">
          <SectionHeader
            title="Stay Updated on Adventures"
            description="Subscribe to our newsletter for exclusive updates on upcoming adventures, mindfulness tips, and special promotions."
          />
          <div className="mx-auto mt-10 max-w-md">
            <NewsletterForm />
          </div>
          <svg
            viewBox="0 0 1024 1024"
            className="absolute left-1/2 top-1/2 -z-10 h-[64rem] w-[64rem] -translate-x-1/2 -translate-y-1/2 [mask-image:radial-gradient(closest-side,white,transparent)]"
            aria-hidden="true"
          >
            <circle
              cx={512}
              cy={512}
              r={512}
              fill="url(#radial)"
              fillOpacity="0.15"
            />
            <defs>
              <radialGradient id="radial">
                <stop stopColor="#49B522" />
                <stop offset={1} stopColor="#317c16" />
              </radialGradient>
            </defs>
          </svg>
        </div>
      </div>
    </div>
  );
}
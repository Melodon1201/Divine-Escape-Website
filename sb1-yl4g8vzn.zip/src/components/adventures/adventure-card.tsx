import { ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { type Adventure } from '@/lib/types';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import { Card } from '../ui/card';

interface AdventureCardProps extends Adventure {}

export function AdventureCard({
  id,
  name,
  description,
  image,
  price,
  duration,
  difficulty,
}: AdventureCardProps) {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const badgeVariant = {
    Easy: 'success',
    Moderate: 'warning',
    Challenging: 'danger',
  } as const;

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.6 }}
    >
      <Card hover className="flex h-full flex-col group">
        <div className="relative overflow-hidden rounded-lg">
          <img
            src={image}
            alt={name}
            className="aspect-video w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
        </div>
        <div className="mt-4 flex flex-1 flex-col">
          <h3 className="text-xl font-semibold text-gray-900 group-hover:text-sage-600 transition-colors">
            {name}
          </h3>
          <p className="mt-2 flex-1 text-gray-600">{description}</p>
          <div className="mt-4 flex items-center gap-x-4">
            <p className="text-sm font-medium text-sage-600">{price}</p>
            <p className="text-sm text-gray-600">{duration}</p>
            <Badge variant={badgeVariant[difficulty]}>{difficulty}</Badge>
          </div>
          <Button
            as={Link}
            to={`/booking?type=${id}`}
            className="mt-4"
            variant="outline"
          >
            Book Now
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </Card>
    </motion.div>
  );
}
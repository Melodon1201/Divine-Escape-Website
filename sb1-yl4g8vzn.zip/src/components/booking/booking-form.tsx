import { zodResolver } from '@hookform/resolvers/zod';
import { Loader2 } from 'lucide-react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { PersonalInfo } from './sections/personal-info';
import { AdventureDetails } from './sections/adventure-details';
import { AdditionalInfo } from './sections/additional-info';
import { EmergencyContact } from './sections/emergency-contact';
import { type BookingFormData, bookingSchema } from '@/lib/schemas/booking';

export function BookingForm() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedType, setSelectedType] = useState<string | undefined>(
    searchParams.get('type') || undefined
  );

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      participants: 1,
      specialAssistance: false,
      adventureType: (searchParams.get('type') as BookingFormData['adventureType']) || undefined,
    },
  });

  const onSubmit = async (data: BookingFormData) => {
    setIsSubmitting(true);
    try {
      // Create mailto link with form data
      const subject = encodeURIComponent(`New Booking Request - ${data.adventureType}`);
      const body = encodeURIComponent(`
Booking Details:

Full Name: ${data.fullName}
Email: ${data.email}
Phone: ${data.phone}

Adventure Type: ${data.adventureType}
Date: ${data.date}
Number of Participants: ${data.participants}
Accommodation: ${data.accommodation}

Dietary Requirements: ${data.dietaryRequirements || 'None'}
Special Assistance Required: ${data.specialAssistance ? 'Yes' : 'No'}

Emergency Contact:
Name: ${data.emergencyContact.name}
Phone: ${data.emergencyContact.phone}
Relationship: ${data.emergencyContact.relationship}

Additional Notes: ${data.additionalNotes || 'None'}
      `);

      // Open default email client with pre-filled email
      window.location.href = `mailto:bookings@holisticdivineescape.com?subject=${subject}&body=${body}`;
      
      toast.success('Booking form opened in your email client. Please send the email to complete your booking.');
      reset();
      navigate('/adventures');
    } catch (error) {
      toast.error('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    reset();
    navigate('/adventures');
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
      <div className="grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-2">
        <PersonalInfo register={register} errors={errors} />
        <AdventureDetails
          register={register}
          errors={errors}
          selectedType={selectedType}
          onTypeChange={(type) => setSelectedType(type)}
        />
        <AdditionalInfo register={register} errors={errors} />
        <EmergencyContact register={register} errors={errors} />
      </div>

      <div className="mt-6 flex items-center justify-end gap-x-6">
        <Button type="button" variant="outline" onClick={handleCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isSubmitting}>
          {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isSubmitting ? 'Processing...' : 'Book Adventure'}
        </Button>
      </div>
    </form>
  );
}
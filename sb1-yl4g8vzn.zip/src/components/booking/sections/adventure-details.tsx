import { type UseFormRegister, type FieldErrors } from 'react-hook-form';
import { CalendarIcon } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/select';
import { availableDates } from '@/lib/constants/dates';
import { type BookingFormData } from '@/lib/schemas/booking';

interface AdventureDetailsProps {
  register: UseFormRegister<BookingFormData>;
  errors: FieldErrors<BookingFormData>;
  selectedType: string | undefined;
  onTypeChange: (type: string) => void;
}

export function AdventureDetails({
  register,
  errors,
  selectedType,
  onTypeChange,
}: AdventureDetailsProps) {
  const renderDateSelection = () => {
    if (!selectedType) {
      return (
        <Input
          {...register('date')}
          type="date"
          error={!!errors.date}
          min={new Date().toISOString().split('T')[0]}
        />
      );
    }

    if (selectedType === 'workshop') {
      return (
        <Select {...register('date')} error={!!errors.date}>
          <option value="">Select a workshop</option>
          {availableDates.workshop.map((workshop) => (
            <option key={workshop.date} value={workshop.date}>
              {workshop.name} ({workshop.duration}) - {new Date(workshop.date).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}
            </option>
          ))}
        </Select>
      );
    }

    if (availableDates[selectedType as keyof typeof availableDates]) {
      const dates = availableDates[selectedType as keyof typeof availableDates];
      if (Array.isArray(dates)) {
        return (
          <Select {...register('date')} error={!!errors.date}>
            <option value="">Select a date</option>
            {dates.map((date) => (
              <option key={date} value={date}>
                {new Date(date).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </option>
            ))}
          </Select>
        );
      }
    }

    return (
      <Input
        {...register('date')}
        type="date"
        error={!!errors.date}
        min={new Date().toISOString().split('T')[0]}
      />
    );
  };

  return (
    <>
      <div>
        <label htmlFor="adventureType" className="block text-sm font-medium text-gray-700">
          Adventure Type
        </label>
        <div className="mt-2">
          <Select 
            {...register('adventureType')} 
            error={!!errors.adventureType}
            onChange={(e) => onTypeChange(e.target.value)}
          >
            <option value="">Select an adventure</option>
            <option value="hiking">Hiking Adventures</option>
            <option value="thrill">Thrill Adventures</option>
            <option value="safari">Safari Experiences</option>
            <option value="mindfulness">Mindfulness Workshops</option>
            <option value="glamping">Luxury Glamping</option>
            <option value="workshop">Special Workshops & Retreats</option>
          </Select>
          {errors.adventureType && (
            <p className="mt-1 text-sm text-red-500">{errors.adventureType.message}</p>
          )}
        </div>
      </div>

      <div>
        <label htmlFor="date" className="block text-sm font-medium text-gray-700">
          Preferred Date
        </label>
        <div className="mt-2">
          <div className="relative">
            {renderDateSelection()}
            <CalendarIcon className="pointer-events-none absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
          </div>
          {errors.date && (
            <p className="mt-1 text-sm text-red-500">{errors.date.message}</p>
          )}
        </div>
      </div>

      <div>
        <label htmlFor="participants" className="block text-sm font-medium text-gray-700">
          Number of Participants
        </label>
        <div className="mt-2">
          <Input
            {...register('participants', { valueAsNumber: true })}
            type="number"
            min="1"
            max="10"
            error={!!errors.participants}
          />
          {errors.participants && (
            <p className="mt-1 text-sm text-red-500">{errors.participants.message}</p>
          )}
        </div>
      </div>

      <div>
        <label htmlFor="accommodation" className="block text-sm font-medium text-gray-700">
          Accommodation Preference
        </label>
        <div className="mt-2">
          <Select {...register('accommodation')} error={!!errors.accommodation}>
            <option value="">Select accommodation</option>
            <option value="standard">Standard</option>
            <option value="luxury">Luxury</option>
            <option value="suite">Suite</option>
          </Select>
          {errors.accommodation && (
            <p className="mt-1 text-sm text-red-500">{errors.accommodation.message}</p>
          )}
        </div>
      </div>
    </>
  );
}
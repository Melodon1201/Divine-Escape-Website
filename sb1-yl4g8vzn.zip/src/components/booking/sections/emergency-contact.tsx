import { type UseFormRegister, type FieldErrors } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { type BookingFormData } from '@/lib/schemas/booking';

interface EmergencyContactProps {
  register: UseFormRegister<BookingFormData>;
  errors: FieldErrors<BookingFormData>;
}

export function EmergencyContact({ register, errors }: EmergencyContactProps) {
  return (
    <div className="sm:col-span-2 space-y-8">
      <div>
        <h3 className="text-lg font-medium text-gray-900">Emergency Contact</h3>
        <div className="mt-6 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-2">
          <div className="sm:col-span-2">
            <label
              htmlFor="emergencyContact.name"
              className="block text-sm font-medium text-gray-700"
            >
              Full Name
            </label>
            <div className="mt-2">
              <Input
                {...register('emergencyContact.name')}
                error={!!errors.emergencyContact?.name}
              />
              {errors.emergencyContact?.name && (
                <p className="mt-1 text-sm text-red-500">
                  {errors.emergencyContact.name.message}
                </p>
              )}
            </div>
          </div>

          <div>
            <label
              htmlFor="emergencyContact.phone"
              className="block text-sm font-medium text-gray-700"
            >
              Phone Number
            </label>
            <div className="mt-2">
              <Input
                {...register('emergencyContact.phone')}
                type="tel"
                error={!!errors.emergencyContact?.phone}
              />
              {errors.emergencyContact?.phone && (
                <p className="mt-1 text-sm text-red-500">
                  {errors.emergencyContact.phone.message}
                </p>
              )}
            </div>
          </div>

          <div>
            <label
              htmlFor="emergencyContact.relationship"
              className="block text-sm font-medium text-gray-700"
            >
              Relationship
            </label>
            <div className="mt-2">
              <Input
                {...register('emergencyContact.relationship')}
                error={!!errors.emergencyContact?.relationship}
              />
              {errors.emergencyContact?.relationship && (
                <p className="mt-1 text-sm text-red-500">
                  {errors.emergencyContact.relationship.message}
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
import { type UseFormRegister, type FieldErrors } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { type BookingFormData } from '@/lib/schemas/booking';

interface AdditionalInfoProps {
  register: UseFormRegister<BookingFormData>;
  errors: FieldErrors<BookingFormData>;
}

export function AdditionalInfo({ register, errors }: AdditionalInfoProps) {
  return (
    <>
      <div className="sm:col-span-2">
        <label
          htmlFor="dietaryRequirements"
          className="block text-sm font-medium text-gray-700"
        >
          Dietary Requirements
        </label>
        <div className="mt-2">
          <Textarea
            {...register('dietaryRequirements')}
            error={!!errors.dietaryRequirements}
            placeholder="Please list any dietary requirements or restrictions"
          />
          {errors.dietaryRequirements && (
            <p className="mt-1 text-sm text-red-500">
              {errors.dietaryRequirements.message}
            </p>
          )}
        </div>
      </div>

      <div className="sm:col-span-2">
        <div className="relative flex items-start">
          <div className="flex h-6 items-center">
            <Input
              {...register('specialAssistance')}
              type="checkbox"
              className="h-4 w-4 rounded border-gray-300 text-sage-600 focus:ring-sage-600"
            />
          </div>
          <div className="ml-3">
            <label htmlFor="specialAssistance" className="text-sm font-medium text-gray-700">
              Special Assistance Required
            </label>
            <p className="text-sm text-gray-500">
              Check this box if you require any special assistance during your adventure.
            </p>
          </div>
        </div>
      </div>

      <div className="sm:col-span-2">
        <label
          htmlFor="additionalNotes"
          className="block text-sm font-medium text-gray-700"
        >
          Additional Notes
        </label>
        <div className="mt-2">
          <Textarea
            {...register('additionalNotes')}
            error={!!errors.additionalNotes}
            placeholder="Any additional information you'd like us to know"
          />
          {errors.additionalNotes && (
            <p className="mt-1 text-sm text-red-500">{errors.additionalNotes.message}</p>
          )}
        </div>
      </div>
    </>
  );
}
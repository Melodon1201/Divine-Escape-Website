import { Link } from 'react-router-dom';
import { brandAssets } from '@/lib/constants/images';

export function Logo() {
  return (
    <Link to="/" className="-m-1.5 p-1.5 flex items-center gap-2">
      <img
        src={brandAssets.logo}
        alt="Divine Escape"
        className="h-12 w-auto"
      />
    </Link>
  );
}
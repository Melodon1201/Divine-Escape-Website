import { MissionSection } from '@/components/about/mission-section';
import { ValuesSection } from '@/components/about/values-section';
import { CtaSection } from '@/components/about/cta-section';
import { Hero } from '@/components/ui/hero';

export function AboutPage() {
  return (
    <div className="bg-white">
      <Hero image="https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?auto=format&fit=crop&q=80&w=2000">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
          Our Story
        </h1>
        <p className="mt-6 max-w-xl text-xl text-gray-200">
        At DivineEscape Holistic Adventures, we believe in the power of stillness, faith, and mindful reflection to inspire healing, growth, and lasting transformation throughout life's adventures.
        </p>
      </Hero>
      <div className="relative isolate">
        <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
          <div className="mx-auto max-w-2xl lg:mx-0 lg:max-w-none">
            <div className="mt-6 flex flex-col gap-x-8 gap-y-20 lg:flex-row">
              <MissionSection />
              <ValuesSection />
            </div>
          </div>
        </div>
      </div>
      <CtaSection />
    </div>
  );
}
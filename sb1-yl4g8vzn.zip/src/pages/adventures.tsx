import { ArrowRight, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { AdventureCard } from '@/components/adventures/adventure-card';
import { Button } from '@/components/ui/button';
import { Hero } from '@/components/ui/hero';
import { adventures } from '@/lib/constants/adventures';

export function AdventuresPage() {
  return (
    <div className="bg-white">
      <Hero image="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=2000">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
          Choose Your Adventure
        </h1>
        <p className="mt-6 max-w-xl text-xl text-gray-200">
          Discover our carefully curated selection of transformative experiences designed to help you
          reconnect with nature and yourself.
        </p>
        <div className="mt-10">
          <Button
            as="a"
            href="https://forms.zohopublic.com/ndumimagd119gm1/form/DivineEscapeRebootRetreat/formperma/EKDUh-v01posU1Y43Gh9suaFGxJQTO9WOwFPkEVprts"
            target="_blank"
            rel="noopener noreferrer"
            size="lg"
            className="bg-white text-sage-700 hover:bg-sage-50"
          >
            Book Reboot the Soul Retreat
            <ExternalLink className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </Hero>

      <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
        <div className="grid grid-cols-1 gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3">
          {adventures.map((adventure) => (
            <AdventureCard key={adventure.id} {...adventure} />
          ))}
        </div>
      </div>
    </div>
  );
}
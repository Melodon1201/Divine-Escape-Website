import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { BlogCard } from '@/components/blog/blog-card';
import { SectionHeader } from '@/components/ui/section-header';
import { Hero } from '@/components/ui/hero';
import { blogPosts } from '@/lib/constants/blog-posts';

export function BlogPage() {
  return (
    <div className="bg-white">
      <Hero image="https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&q=80&w=2000">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
          Adventure Insights
        </h1>
        <p className="mt-6 max-w-xl text-xl text-gray-200">
          Discover stories, tips, and wisdom from our adventures and wellness experiences.
        </p>
      </Hero>
      <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
        <div className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-x-8 gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-3">
          {blogPosts.map((post) => (
            <BlogCard key={post.id} {...post} />
          ))}
        </div>
        <div className="mt-16 text-center">
          <Button as={Link} to="/contact" variant="outline" size="lg">
            Get in Touch for Custom Content
          </Button>
        </div>
      </div>
    </div>
  );
}
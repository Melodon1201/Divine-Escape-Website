import { BookingForm } from '@/components/booking/booking-form';
import { Hero } from '@/components/ui/hero';

export function BookingPage() {
  return (
    <div className="bg-gray-50">
      <Hero image="https://images.unsplash.com/photo-1426604966848-d7adac402bff?auto=format&fit=crop&q=80&w=2000">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
          Book Your Escape
        </h1>
        <p className="mt-6 max-w-xl text-xl text-gray-200">
          Ready to embark on your journey? Fill out the form below to book your Divine Escape experience.
        </p>
      </Hero>
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl">
          <div className="space-y-12">
            <BookingForm />
          </div>
        </div>
      </div>
    </div>
  );
}
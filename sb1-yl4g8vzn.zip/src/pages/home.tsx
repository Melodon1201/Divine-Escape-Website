import { HeroSection } from '@/components/home/sections/hero-section';
import { WelcomeSection } from '@/components/home/sections/welcome-section';
import { VisionSection } from '@/components/home/sections/vision-section';
import { DifferenceSection } from '@/components/difference/difference-section';
import { TestimonialSection } from '@/components/testimonials/testimonial-section';
import { NewsletterSection } from '@/components/newsletter/newsletter-section';
import { LegalSection } from '@/components/legal/legal-section';

export function HomePage() {
  return (
    <div className="bg-white">
      <HeroSection />
      <WelcomeSection />
      <DifferenceSection />
      <VisionSection />
      <TestimonialSection />
      <NewsletterSection />
      <LegalSection />
    </div>
  );
}
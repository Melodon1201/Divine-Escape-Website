import { FaqItem } from '@/components/faq/faq-item';
import { SectionHeader } from '@/components/ui/section-header';
import { Hero } from '@/components/ui/hero';
import { faqs } from '@/lib/constants/faqs';

export function FaqPage() {
  return (
    <div className="bg-white">
      <Hero image="https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?auto=format&fit=crop&q=80&w=2000">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
          Frequently Asked Questions
        </h1>
        <p className="mt-6 max-w-xl text-xl text-gray-200">
          Find answers to common questions about our adventures, booking process, and what to expect.
        </p>
      </Hero>
      <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8 lg:py-40">
        <div className="mx-auto max-w-4xl divide-y divide-gray-900/10">
          <dl className="mt-10 space-y-6 divide-y divide-gray-900/10">
            {faqs.map((faq) => (
              <FaqItem key={faq.question} {...faq} />
            ))}
          </dl>
        </div>
      </div>
    </div>
  );
}
import { ContactForm } from '@/components/contact/contact-form';
import { ContactInfo } from '@/components/contact/contact-info';
import { Hero } from '@/components/ui/hero';

export function ContactPage() {
  return (
    <div className="relative isolate bg-white">
      <Hero image="https://images.unsplash.com/photo-1418065460487-3e41a6c84dc5?auto=format&fit=crop&q=80&w=2000">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
          Get in Touch
        </h1>
        <p className="mt-6 max-w-xl text-xl text-gray-200">
          Have questions about our adventures? Want to customize your experience? We're here to help.
        </p>
      </Hero>
      <div className="mx-auto grid max-w-7xl grid-cols-1 lg:grid-cols-2">
        <ContactInfo />
        <ContactForm />
      </div>
    </div>
  );
}
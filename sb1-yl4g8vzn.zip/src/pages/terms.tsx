import { SectionHeader } from '@/components/ui/section-header';
import { Hero } from '@/components/ui/hero';
import { legalContent } from '@/lib/constants/legal';

export function TermsPage() {
  return (
    <div className="bg-white">
      <Hero image="https://images.unsplash.com/photo-1472214103451-9374bd1c798e?auto=format&fit=crop&q=80&w=2000">
        <h1 className="text-4xl font-bold tracking-tight text-white sm:text-6xl">
          Terms & Conditions
        </h1>
        <p className="mt-6 max-w-xl text-xl text-gray-200">
          Important information about our policies and procedures.
        </p>
      </Hero>
      <div className="mx-auto max-w-7xl px-6 py-24 sm:py-32 lg:px-8">
        <div className="mx-auto max-w-3xl">
          <div className="prose prose-sage max-w-none">
            <p className="text-lg leading-8 text-gray-600">
              {legalContent.terms.content}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
import { z } from 'zod';

export const bookingSchema = z.object({
  fullName: z.string().min(2, 'Full name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email address'),
  phone: z.string().min(10, 'Please enter a valid phone number'),
  participants: z.number().min(1).max(10),
  adventureType: z.enum(['hiking', 'thrill', 'safari', 'mindfulness', 'glamping', 'workshop']),
  date: z.string().min(1, 'Please select a date'),
  accommodation: z.enum(['standard', 'luxury', 'suite']),
  dietaryRequirements: z.string().optional(),
  specialAssistance: z.boolean().default(false),
  emergencyContact: z.object({
    name: z.string().min(2, 'Emergency contact name must be at least 2 characters'),
    phone: z.string().min(10, 'Please enter a valid phone number'),
    relationship: z.string().min(2, 'Please specify the relationship'),
  }),
  additionalNotes: z.string().optional(),
});

export type BookingFormData = z.infer<typeof bookingSchema>;
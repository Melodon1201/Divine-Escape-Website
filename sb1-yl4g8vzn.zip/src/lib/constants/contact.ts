export const contactInfo = {
  address: {
    line1: 'Gauteng',
    line2: '',
  },
  phone: '066 231 3908',
  email: 'info@holisticdivineescape.com',
} as const;
export const navigation = {
  main: [
    { name: 'Home', href: '/' },
    { name: 'About', href: '/about' },
    { name: 'Adventures', href: '/adventures' },
    { name: 'Blog', href: '/blog' },
    { name: 'Contact', href: '/contact' },
    { name: 'FAQ', href: '/faq' },
  ],
  social: [
    {
      name: 'Facebook',
      href: 'https://www.facebook.com/share/Za59i7YNQUDxbqAM/?mibextid=LQQJ4d',
      icon: 'Facebook',
    },
    {
      name: 'Instagram',
      href: 'https://www.instagram.com/divineescape_?igsh=dGR5aTB5dGlsM2x6&utm_source=qr',
      icon: 'Instagram',
    },
    {
      name: 'TikTok',
      href: '#',
      icon: 'TikTok',
    },
  ],
} as const;
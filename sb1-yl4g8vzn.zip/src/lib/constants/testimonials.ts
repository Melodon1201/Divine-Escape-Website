import { testimonialAvatars } from './images';

export const testimonials = [
  {
    content: "Divine Escape helped me rediscover my connection with nature. The mountain meditation was transformative.",
    author: "Sarah Johnson",
    role: "Marketing Executive",
    image: testimonialAvatars.sarah,
  },
  {
    content: "The perfect blend of adventure and mindfulness. I returned to work feeling refreshed and inspired.",
    author: "Michael Chen",
    role: "Software Engineer",
    image: testimonialAvatars.michael,
  },
  {
    content: "The luxury glamping experience exceeded all expectations. A true escape from the digital world.",
    author: "Emma Thompson",
    role: "Financial Advisor",
    image: testimonialAvatars.emma,
  },
] as const;
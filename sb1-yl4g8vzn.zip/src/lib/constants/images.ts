// Hero images
export const heroImages = {
  home: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05',
  about: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d',
  adventures: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b',
  blog: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e',
  booking: 'https://images.unsplash.com/photo-1426604966848-d7adac402bff',
  contact: 'https://images.unsplash.com/photo-1418065460487-3e41a6c84dc5',
  faq: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05',
  privacy: 'https://images.unsplash.com/photo-1511497584788-876760111969',
  terms: 'https://images.unsplash.com/photo-1472214103451-9374bd1c798e'
} as const;

// Brand assets
export const brandAssets = {
  logo: 'public/images/brand/4.png',
  favicon: 'public/images/brand/4.png'
} as const;

// Feature images
export const featureImages = {
  hiking: 'https://images.unsplash.com/photo-1551632811-561732d1e306',
  thrill: 'https://images.unsplash.com/photo-1578575437130-527eed3abbec',
  safari: 'https://images.unsplash.com/photo-1516426122078-c23e76319801',
  mindfulness: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773',
  glamping: 'https://images.unsplash.com/photo-1521401830884-6c03c1c87ebb'
} as const;

// Testimonial avatars
export const testimonialAvatars = {
  sarah: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330',
  michael: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d',
  emma: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80'
} as const;
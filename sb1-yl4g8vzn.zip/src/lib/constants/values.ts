export const values = [
  {
    name: 'Community',
    description: 'Building connections with like-minded adventurers.',
  },
  {
    name: 'Mindfulness',
    description: 'Fostering awareness and presence.',
  },
  {
    name: 'Holistic Well-Being',
    description: 'Encouraging spiritual, mental, and emotional growth.',
  },
] as const;
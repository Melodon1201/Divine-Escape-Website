export const availableDates = {
  hiking: [
    '2025-01-25',
    '2025-03-29',
    '2025-07-26',
    '2025-10-25',
  ],
  thrill: [
    '2025-05-31',
    '2025-11-29',
  ],
  safari: [
    '2025-02-22',
    '2025-08-30',
  ],
  glamping: [
    '2025-06-28',
  ],
  workshop: [
    {
      name: 'Annual Workshop Retreat',
      duration: '2 nights',
      date: '2025-04-11',
    },
    {
      name: 'Quarter Therapeutic Workshop',
      duration: '2 nights',
      date: '2025-09-27',
    },
    {
      name: 'Annual Holistic Adventure Gateway Reboot Retreat',
      duration: '5 nights',
      date: '2025-12-13',
    },
  ],
} as const;
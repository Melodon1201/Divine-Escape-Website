import { featureImages } from './images';

export const adventures = [
  {
    id: 'hiking',
    name: 'Hiking Adventures',
    description: 'Meditation, reflections, scenic picnic, and a light lunch.',
    image: featureImages.hiking,
    price: 'From R199',
    duration: '1 day',
    difficulty: 'Moderate',
  },
  {
    id: 'thrill',
    name: 'Thrill Adventures',
    description: 'Activities like quadbiking, ensuring safety and excitement.',
    image: featureImages.thrill,
    price: 'From R499',
    duration: '1 day',
    difficulty: 'Challenging',
  },
  {
    id: 'safari',
    name: 'Safari Experiences',
    description: 'Wildlife encounters via game drives and walks.',
    image: featureImages.safari,
    price: 'From R499',
    duration: '2 days',
    difficulty: 'Easy',
  },
  {
    id: 'mindfulness',
    name: 'Mindfulness Workshops',
    description: 'Guided meditations and peaceful retreats.',
    image: featureImages.mindfulness,
    price: 'From R399',
    duration: '1 day',
    difficulty: 'Easy',
  },
  {
    id: 'glamping',
    name: 'Luxury Glamping',
    description: 'Premium accommodations with digital detox activities.',
    image: featureImages.glamping,
    price: 'From R2999',
    duration: '2 days',
    difficulty: 'Easy',
  },
] as const;
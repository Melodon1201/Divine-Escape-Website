export const faqs = [
  {
    question: 'What should I bring?',
    answer:
      'We recommend bringing comfortable clothing suitable for the activity, sturdy shoes, sunscreen, a hat, water bottle, and any personal items you might need. A detailed packing list will be provided upon booking.',
  },
  {
    question: 'Are there group discounts?',
    answer:
      'Yes! We offer group discounts for parties of 6 or more. Contact us directly for special group rates and custom packages.',
  },
  {
    question: 'What is the cancellation policy?',
    answer:
      'Bookings can be cancelled up to 14 days before the scheduled date for a full refund. Cancellations within 14 days may be eligible for partial refunds or credit toward future adventures.',
  },
  {
    question: 'How fit do I need to be?',
    answer:
      'Our adventures cater to various fitness levels. Each activity is clearly marked with its intensity level, and our team can help you choose the most suitable experience for you.',
  },
  {
    question: 'What happens in case of bad weather?',
    answer:
      'Safety is our priority. In case of severe weather, we may reschedule the activity or offer alternative indoor programs. You will be notified at least 24 hours in advance.',
  },
  {
    question: 'Are meals included?',
    answer:
      'Most full-day adventures include meals. The specific meal inclusions are listed in each adventure package. We accommodate dietary restrictions with advance notice.',
  },
] as const;
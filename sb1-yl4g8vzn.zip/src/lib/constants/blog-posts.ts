export const blogPosts = [
  {
    id: 1,
    title: '10 Tips for Your First Mountain Meditation',
    description:
      'Discover essential tips to make your first mountain meditation experience truly transformative.',
    date: '2024-03-15',
    category: 'Mindfulness',
    author: 'Sarah Johnson',
    image: 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?auto=format&fit=crop&q=80&w=1000',
  },
  {
    id: 2,
    title: 'How to Prepare for a Quadbiking Adventure',
    description:
      'Essential preparation tips and safety guidelines for an unforgettable quadbiking experience.',
    date: '2024-03-10',
    category: 'Adventure',
    author: 'Mike Thompson',
    image: 'https://images.unsplash.com/photo-1682687220063-4742bd7fd538?auto=format&fit=crop&q=80&w=1000',
  },
  {
    id: 3,
    title: 'Mindfulness Practices for Busy Professionals',
    description:
      'Learn practical mindfulness techniques that can be integrated into your busy schedule.',
    date: '2024-03-05',
    category: 'Wellness',
    author: 'Emily Chen',
    image: 'https://images.unsplash.com/photo-1682687220199-d0124f48f95b?auto=format&fit=crop&q=80&w=1000',
  },
] as const;
import { featureImages } from './images';

export const features = [
  {
    name: 'Hiking Adventures',
    description: 'Mindful escapes to nature that nurture the soul.',
    image: featureImages.hiking,
  },
  {
    name: 'Thrill Adventures',
    description: 'Adrenaline-pumping experiences that challenge the spirit.',
    image: featureImages.thrill,
  },
  {
    name: 'Safari Experiences',
    description: 'Immersive wildlife encounters that inspire awe and reflection.',
    image: featureImages.safari,
  },
  {
    name: 'Mindfulness Workshops',
    description: 'Deepen your inner peace through guided mindfulness practices.',
    image: featureImages.mindfulness,
  },
  {
    name: 'Luxury Glamping',
    description: "Relax in nature's embrace while enjoying premium comfort.",
    image: featureImages.glamping,
  },
] as const;
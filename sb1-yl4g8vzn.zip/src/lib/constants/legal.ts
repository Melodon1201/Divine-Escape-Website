export const legalContent = {
  terms: {
    title: 'Terms & Conditions',
    content: `By booking with Divine Escape, you agree to our terms and conditions. These include our cancellation and refund policies, participation requirements, and safety protocols. Divine Escape reserves the right to modify activities due to weather or unforeseen circumstances to ensure the safety and enjoyment of all participants.`,
  },
  privacy: {
    title: 'Privacy Policy',
    content: `Your privacy matters to us. We collect and process your personal data strictly for booking purposes, ensuring its safety and confidentiality. We do not share your information with third parties without explicit consent. Learn how we protect and manage your data.`,
  },
} as const;
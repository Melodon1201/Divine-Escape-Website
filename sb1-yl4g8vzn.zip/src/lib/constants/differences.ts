export const differences = [
  {
    title: 'Small Groups',
    description: 'Intimate groups of 6-10 participants ensure personalized attention and meaningful connections.',
    icon: 'Users',
  },
  {
    title: 'Mountain Meditation',
    description: 'Unique meditation experiences in breathtaking natural settings for deep spiritual connection.',
    icon: 'Mountain',
  },
  {
    title: 'Luxury Glamping',
    description: 'Premium accommodation that blends the serenity of nature with modern comforts.',
    icon: 'Tent',
  },
  {
    title: 'Mindful Growth',
    description: 'Focused activities that promote spiritual awareness and personal development.',
    icon: 'Sprout',
  },
] as const;
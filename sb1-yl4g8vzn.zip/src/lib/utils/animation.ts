import { type MotionProps } from 'framer-motion';

export const fadeInUp: MotionProps = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

export const slideIn = (direction: 'left' | 'right'): MotionProps => ({
  initial: { opacity: 0, x: direction === 'left' ? -100 : 100 },
  animate: { opacity: 1, x: 0 },
  transition: { duration: 0.6 },
});

export const scaleIn: MotionProps = {
  initial: { opacity: 0, scale: 0.9 },
  animate: { opacity: 1, scale: 1 },
  transition: { duration: 0.4 },
};
export interface BlogPost {
  id: number;
  title: string;
  description: string;
  date: string;
  category: string;
  author: string;
  image: string;
}

export interface Adventure {
  id: string;
  name: string;
  description: string;
  image: string;
  price: string;
  duration: string;
  difficulty: 'Easy' | 'Moderate' | 'Challenging';
}

export interface Testimonial {
  content: string;
  author: string;
  role: string;
  image: string;
}

export interface Value {
  name: string;
  description: string;
}